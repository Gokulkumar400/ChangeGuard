# ChangeGuard

ChangeGuard is a developer tool in development for checking code changes made
by AI coding agents. Phase 1 provides a minimal local CLI foundation; the
change-aware verification engine remains unimplemented.

> **Status:** The Phase 1 CLI foundation is implemented. Phase 2 release
> preparation is in progress. It supports help, version, usage on no arguments,
> and invalid-argument handling; it does not perform verification. No npm
> package has been published.

## Product principles

- Report which behavior was verified, which checks failed, and what remains
  unverified.
- Do not claim an entire application is correct solely because a test suite
  passes.
- Treat repository content and commands as potentially untrusted.
- Make the evidence and limitations of each result visible.

## Intended audience

Developers and teams using AI coding agents in Node.js and TypeScript projects
who want a clearer, change-aware verification workflow.

## Project status

**Phase 0 and Phase 1 are complete. Phase 2 release preparation is in progress.**
No npm package has been published.
Initial development and validation are planned to take place in Replit.

See [`DEVELOPMENT_PLAN.md`](DEVELOPMENT_PLAN.md) for the staged roadmap and
[`REPLIT.md`](REPLIT.md) for handover and agent instructions.

## Local command

The local CLI command is `changeguard` after building or installing the local
package. It supports `--help`, `--version`, and help/usage output when run
without arguments. An unauthenticated request to the public npm registry for
`changeguard` returned HTTP 404 on 2026-10-27, so no package record was found at
that time. This does not reserve the name or guarantee a future publish will
succeed; the package name remains provisional until confirmed and must be
rechecked before release. The CLI command name and npm package name are separate
decisions.

The user-proposed spelling `TestPilot` contains uppercase letters; the lowercase
name `testpilot` already has a public registry record. Alternative candidates
`changeguard-cli`, `changeguard-verify`, and `changeguard-check` returned HTTP
404 at lookup time, but none is reserved. Final package-name selection remains
pending.

The package version remains `0.0.0` as selected for the initial release. The
package declares MIT licensing, and the copyright-holder placeholder in
[`LICENSE`](LICENSE) has been replaced with the user-provided notice.

## License

The project uses the MIT License. The copyright notice in [`LICENSE`](LICENSE)
reflects the holder supplied by the user.
