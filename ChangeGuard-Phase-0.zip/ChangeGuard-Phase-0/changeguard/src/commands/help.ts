export const HELP_TEXT = [
  "ChangeGuard",
  "CLI foundation for change-aware verification of Node.js and TypeScript projects.",
  "",
  "Usage: changeguard [options]",
  "",
  "Options:",
  "  --help     Show this help message",
  "  --version  Show the package version",
].join("\n");
